# miRNAのリストとシグナル値のデータを与えると、miRNA間の相関を計算し、相関係数とそのグラフを保存する

setwd("D:/users/YB249/Documents/判別式構築スクリプト/モデル構築/その他")
# チップデータ
norm.df <- read.csv("norm_log_data.csv", row.names = 1, check.names = F)
# 評価対象miRNA
marker <- scan("marker_lasso.txt", what = "")

# hsa-がついている場合は削除
colnames(norm.df) <- gsub("hsa-", "", colnames(norm.df))
# 対象miRNAだけにする
norm.df <- norm.df[marker]
cor.mat <- cor(norm.df, method = "pearson")

library(corrplot)
png("correlations.png")
corrplot(cor.mat)
dev.off()

write.csv(cor.mat, "correlations.csv")
