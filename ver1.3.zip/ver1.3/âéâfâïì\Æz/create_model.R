# 判別式再構築
# 前処理済みのチップデータを読み込む
# 疾患名を表すclass列、学習群か検証群か示すcohort列があると想定する
library(dplyr)
library(caret)
library(doParallel)

# 実行開始時間を記録
start <- proc.time()

# Rscriptでの実行時に渡したconfigファイル名を読み込む
# Rを開いて実行する場合はこちらの2行をコメントアウト
args <- commandArgs()
cfg <- read.csv(args[6], header=F, stringsAsFactors=F)

# # debug用（Rでの実行時に使う）
# setwd("D:/users/YB249/Documents/判別式構築スクリプト/モデル構築")
# cfg <- read.csv("config_model.csv", header=F, stringsAsFactors=F)

# cfgで指定したパラメータの取得
source("set_params.R")
# 変数選択とモデル構築用の関数を読み込む
source("feature_selection_modeling.R")


################################
# 並列処理する場合はクラスターを登録
if (lda.parallel){
  # 最大コア数に設定
  cl.num <- detectCores()
  cl <- makeCluster(cl.num - 2)
  registerDoParallel(cl)
}

# モデル構築用データを読み込む
train.data.all <- read.csv(train.data, check.names=F)
# train.data.all <- read.csv("norm_log_data.csv", check.names=F)

# ID（検体名）, class（疾患名）, Y列（陽性: 1, 陰性: 0, 解析対象外: 欠損）
# 現在の実装ではclass列は用いていないので省略可
ref.table <- read.csv(ref.table.name)
# ref.table <- read.csv("sample_ref_table.csv")
ref.table <- ref.table %>% filter(!is.na(Y))

# IDでマージする
train.data.all <- merge(train.data.all, ref.table, by = "ID")

# 目的変数を別の変数として保存する
train.y.all <- train.data.all$Y

# # 疾患名も保存しておく
# train.data.all.class <- train.data.all$class

# 説明変数をmiRNAのみにする
train.X.all <- train.data.all %>% 
  dplyr::select(contains("miR")) %>% 
  rename_all(function(x) gsub("hsa-", "", x))

# 結果出力用のディレクトリを作成し移動
dir.create(output.dir)
setwd(output.dir)

if (draw.plot){
  # save plots
  pdf("res_plot.pdf")
  # 1ページに4枚のプロットを描き、タイトル用に上の余白を設定
  par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  
  # beeswarmの保存用フォルダ
  dir.create("beeswarm")
}

#####################################
## 10回繰り返しのCV
# 平均判別性能とばらつき、判別式の係数を保存
score.cv.rep.all <- coef.cv.rep.all <- NULL
for (Round in 1:n_rep){

cat("\n# Round", Round, "started\n")  
# サンプル分割用の乱数のシードを決定(Roundごとに変える)
set.seed(Round + seed)

# factor型を引数に与えると、各水準の割合が均等になるように分割する
folds.data <- caret::createFolds(train.y.all, k = k, list = F)

# k-fold CV
# 1回のCVでの結果を保存
score.cv.all <- coef.cv.all <- NULL
for (n_CV in 1:k){
  # n_CV <- 1 # どのfoldが検証群か？
  # n_CV番目のサブセットが検証サブセットになる
  train.X <- train.X.all[folds.data != n_CV,]
  train.y <- train.y.all[folds.data != n_CV]
  test.X <- train.X.all[folds.data == n_CV,]
  test.y <- train.y.all[folds.data == n_CV]
  
  ### マーカー選択とアルゴリズム構築の方法を選択
  # Logisttic regression + lassoによる変数選択とモデル構築
  if (method == "LogisticLasso"){
    # logistic regression + lassoでマーカー選択とモデル構築
    res <- LogisticLasso(train.X, train.y, test.X, test.y, cor.check=lasso.cor.check, 
                         cor.threshold=cor.threshold, alpha=lasso.alpha, lambda.method=lasso.lambda.method, 
                         fix.num.n=lasso.fix.num, draw.plot=draw.plot, n=Round, k=n_CV)
  } else if (method == "pre-selection"){ # 事前に変数選択する方法
    ## 変数選択を行う
    # p-valueとfold changeで指定数だけ変数選択
    if (selection.method == "p_fc"){
      marker <- FS_p_fc(train.X, train.y, feature.num=FS.feature.num, 
                        cor.threshold=cor.threshold, draw.plot=draw.plot)
    } else if (selection.method == "LogisticLasso"){
      # Logisttic regression + lassoで変数選択
      marker <- FS_LogisticLasso(train.X, train.y, lambda.method=lasso.lambda.method, 
                                 cor.check=lasso.cor.check, cor.threshold=cor.threshold, 
                                 draw.plot=draw.plot)
    } else {
      stop("Inappropriate selection method. Check configuration.")
    }
    
    cat(length(marker), "markers selected\n")
    
    # ToDo: 選択マーカーを記録する。各ループの結果を保存する変数を設ける。
    
    # 選択マーカーのみのデータ
    train.X.sel <- train.X[, marker] 
    test.X.sel <- test.X[, marker] 
      
    ## モデル構築を行う
    # Logistic regression + BICでモデル構築
    if (modeling.method == "LogisticBIC"){
      res <- modeling_LogisticBIC(train.X.sel, train.y, test.X.sel, test.y, 
                                  draw.plot=draw.plot, n=Round, k=n_CV)
    } else if (modeling.method == "LDA"){
      # 線形判別分析でモデル構築
      # あまりに組み合わせ数が多い場合は時間がかかりすぎるので実行停止
      # if (choose(length(marker), lda.combn.num) * n_rep * k > 10^6){
      #   stop("It will take too long to finish. Try different configuration.")
      # }
      if (lda.parallel){
        # 並列処理する場合
        res <- modeling_LDA_parallel(train.X.sel, train.y, test.X.sel, test.y, 
                                     combn_num=lda.combn.num, draw.plot=draw.plot, n=Round, k=n_CV)
      } else {
        res <- modeling_LDA(train.X.sel, train.y, test.X.sel, test.y, 
                            combn_num=lda.combn.num, draw.plot=draw.plot, n=Round, k=n_CV)
      }
    } else {
      stop("Inappropriate modeling method. Check configuration.")
    }
    
    # 各foldの結果を結合しやすいように、用いられなかった変数の係数を0で埋めておく
    coef_names <- c(colnames(train.X), "intercept")
    coef <- rep(0, length(coef_names))
    names(coef) <- coef_names
    coef[names(res$coef)] <- unlist(res$coef)
    res$coef <- coef
  } else {
    stop("Inappropriate method. Check configuration")
  }
  
  # 判別スコアと係数
  score.cv.all <- rbind(score.cv.all, res$score)
  coef.cv.all <- rbind(coef.cv.all, t(res$coef))
}

score.cv.all <- cbind(round=Round, fold=1:k, score.cv.all)
coef.cv.all <- cbind(round=Round, fold=1:k, coef.cv.all)
rownames(score.cv.all) <- rownames(coef.cv.all) <- NULL

# 各iterationの結果を連結
score.cv.rep.all <- rbind(score.cv.rep.all, score.cv.all)
coef.cv.rep.all <- rbind(coef.cv.rep.all, coef.cv.all)

}

# plot deviceを閉じる
if (draw.plot) dev.off()

# 並列処理する場合はクラスターをとめる
if (lda.parallel) stopCluster(cl)

score.cv.rep.all <- data.frame(score.cv.rep.all, check.names = F)
coef.cv.rep.all <- data.frame(coef.cv.rep.all, check.names = F)
write.csv(score.cv.rep.all, "score.csv", row.names = F)
write.csv(coef.cv.rep.all, "coef.csv", row.names = F)

# 各k-fold CVでの平均値とSD
round_stat <- score.cv.rep.all %>% 
  group_by(round) %>% 
  dplyr::select(-fold, -contains("cutoff")) %>% 
  summarise_all(funs(mean, sd))

# 全体での平均値とSD
all_stat <- score.cv.rep.all %>% 
  dplyr::select(-fold, -round, -contains("cutoff")) %>% 
  summarise_all(funs(mean, sd))

# 上記2つをまとめる
# LogisticLassoの場合は3通りのカットオフがあることに注意
# if (method == "LogisticLasso"){
#   all_stat <- rbind(round_stat, c(round="all", all_stat)) %>% 
#     # 列を並び替える
#     dplyr::select(round, starts_with('AUC'), starts_with('1'), starts_with('2'), starts_with('3')) %>% 
#     mutate_if(is.numeric, round, 3)
# } else {
all_stat <- rbind(round_stat, c(round="all", all_stat)) %>%
  mutate_if(is.numeric, round, 3)
# }

write.csv(all_stat, "all_stat.csv", row.names=F)

# パラメータ設定を保存しておく
write.table(cfg, "config_model.csv", sep=",", col.names=F, row.names=F)

# 実行時間を出力
cat("Process finished in", (proc.time() - start)[3], "seconds\n")
setwd("..")
