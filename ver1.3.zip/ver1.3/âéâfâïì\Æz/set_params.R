
## 各種パラメータの設定
# 学習用データ。1列目が検体名で、class列に陽性・陰性を1, 0で表したデータを入れる。
train.data <- cfg[cfg[,1] == "train", 2]

# 検体名と疾患、陽性・陰性の対応表
ref.table.name <- cfg[cfg[,1] == "ref_table", 2]
  
# 出力先のフォルダ名
output.dir <- cfg[cfg[,1] == "output_dir", 2]
# configファイルで指定がない場合はこちらでデフォルト値を設定
if (length(output.dir) == 0) output.dir <- "output"

# CVの繰り返し数
n_rep <- as.numeric(cfg[cfg[,1] == "repeat_n", 2]) 
if (length(n_rep) == 0) n_rep <- 10

# k分割時の乱数シード
seed <- as.numeric(cfg[cfg[,1] == "seed", 2]) 
if (length(seed) == 0) seed <- 0

# CV時の分割数
k <- as.numeric(cfg[cfg[,1] == "cv_k", 2]) 
if (length(k) == 0) k <- 5 

# プロットを作成するかどうか
draw.plot <- cfg[cfg[,1] == "plot", 2] 
if (length(draw.plot) == 0) draw.plot <- T


# ToDO: 陽性群のサブグループごとの感度を算出する場合
# ToDO: 陰性群のサブグループごとの特異度を算出する場合
# disease列の各項目(疾患)ごとに感度・特異度を算出する

# 変数選択及びモデル構築の方法
# method <- c("LogisticLasso", "pre-selection")[2]
method <- cfg[cfg[,1] == "method", 2]
if (length(method) == 0) method <- "LogisticLasso"

# 変数選択の方法
# selection.method <- c("p_fc", "LogisticLasso")[1]
selection.method <- cfg[cfg[,1] == "selection_method", 2]
if (length(selection.method) == 0) selection.method <- "p_fc"

# モデル構築の方法
# modeling.method <- c("LogisticBIC", "LDA")[2]
modeling.method <- cfg[cfg[,1] == "modeling_method", 2]
if (length(modeling.method) == 0) modeling.method <- "LDA"


# Logistic Lasso
# glmnetのパラメータ。Lassoの場合alpha=1, Ridgeの場合alpha=0
lasso.alpha <- cfg[cfg[,1] == "Lasso_alpha", 2]
if (length(lasso.alpha) == 0) lasso.alpha <- 1

# glmnetのパラメータlambdaの決め方
# lasso.lambda.method <- c("min", "1se", "fix.num") 
lasso.lambda.method <- cfg[cfg[,1] == "Lasso_lambda_method", 2]
if (length(lasso.lambda.method) == 0) lasso.lambda.method <- "1se"

# lasso.lambda.method="fix.num"の場合に選択する変数の数
# lasso.fix.num <- c(4, 5, 6) 
lasso.fix.num <- as.numeric(cfg[cfg[,1] == "Lasso_fix_num", 2])
if (length(lasso.fix.num) == 0) lasso.fix.num <- 5

# 相関が高いmiRNAを事前に除外するかどうか。method="LogisticLasso"の場合と
# selection.method="LogisticLasso"の場合のどちらでも使われる
lasso.cor.check <- cfg[cfg[,1] == "Lasso_cor_ck", 2]
if (length(lasso.cor.check) == 0) lasso.cor.check <- F

# 相関が高いとする際の閾値
# LogisticLassoに加え、p-valueで変数選択する際にも用いられる
cor.threshold <- as.numeric(cfg[cfg[,1] == "cor_threshold", 2])
if (length(cor.threshold) == 0) cor.threshold <- 0.9


# selection.method="p_fc"の場合の変数選択数
FS.feature.num <- as.numeric(cfg[cfg[,1] == "FS_feature_num", 2])
if (length(FS.feature.num) == 0) FS.feature.num <- 10

# LDAでの変数の組み合わせ数
lda.combn.num <- as.numeric(cfg[cfg[,1] == "LDA_combn_num", 2])
if (length(lda.combn.num) == 0) lda.combn.num <- 5

# LDAでの判別式構築時に並列処理を行うかどうか
lda.parallel <- cfg[cfg[,1] == "LDA_parallel", 2]
if (length(lda.parallel) == 0) lda.parallel <- TRUE