# 特徴量選択とモデル構築用の関数
library(glmnet)
library(pROC)
library(tibble)
library(dplyr)
library(MASS)
library(caret)
library(doParallel)
library(beeswarm)

# Logisttic regression + lassoによる変数選択とモデル構築
# テストデータのAUC、3通りのカットオフ値による判別性能、係数のリストを返す
LogisticLasso <- function(train_X, train_y, test_X, test_y, cor.check=F, cor.threshold=0.9,
                          alpha=1, lambda.method="min", fix.num.n=5, draw.plot=T, ...){
  # lambda.method <- c("min", "1SE", "fix.num") # パラメータlambdaの決め方
  # fix.num.n <- c(4, 5, 6) # 選択する変数の数を固定する場合
  
  # # 相関係数が高い変数を除外  ## ToDo: 除外したmiRNAについても、係数を０などでうめておく必要がある
  # if (cor.check){
  #   remove.id <- caret::findCorrelation(cor(train_X), cutoff = cor.threshold)
  #   
  #   if (length(remove.id) == 0){
  #     cat("No highly correlated miRNAs found\n")
  #   } else {
  #     cat(colnames(train_X)[remove.id], "removed due to high correlation\n")
  #   }
  # 
  #   train_X <- train_X[, -remove.id]
  #   test_X <- test_X[, -remove.id]
  # }
  if (cor.check) print("cor.check has not been implemented yet. Returning the result without cor.check\n")
    
  #### lambdaを求める
  # lambdaの最適値をCVで決める
  lasso.cv <- cv.glmnet(as.matrix(train_X), train_y, 
                        family = "binomial", alpha = alpha, # logistic + lasso
                        # type.measureはdeviance, class, auc, mse, maeから選択
                        nfolds = 10, type.measure = "deviance")
  lasso <- glmnet(as.matrix(train_X), train_y, family = "binomial", alpha = alpha)
  
  if (lambda.method == "min") {
    lambda <- lasso.cv$lambda.min
  } else if (lambda.method == "1se"){
    lambda <- lasso.cv$lambda.1se
  } else if (lambda.method == "fix.num") {
    # 変数の数がfix.num.nまたはそれ以下の数になる最小のラムダにする
    lambda <- lasso.cv$lambda[max(which(lasso.cv$nzero <= fix.num.n))]
  }
  
  # 指定したlambdaでの係数
  coef.data <- as.matrix(coef(lasso.cv, s=lambda))
  # coef.data <- coef.data[coef.data != 0, , drop=F]
  # colnames(coef.data) <- paste("fold", n_CV, "lamnda.min", sep = "_")
  colnames(coef.data) <- "coef"
  
  # 改名して最後尾に移動させる
  rownames(coef.data)[1] <- "intercept"
  coef.data <- coef.data[c(2:nrow(coef.data), 1), , drop=F]
  
  # 選択マーカー数を出力
  cat(sum(coef.data != 0) - 1, "markers used for the model\n")
  
  # 学習・検証サブセットでの予測確率
  pred.prob.train <- predict(lasso.cv, as.matrix(train_X), 
                             s=lambda, type="response")
  pred.prob.test <- predict(lasso.cv, as.matrix(test_X), 
                            s=lambda, type="response")
  
  # ROC curveから学習群・検証群のAUCを算出
  mroc.train <- roc(train_y, pred.prob.train[,1])
  
  # 学習群で最適な閾値を決定
  # 最適動作点が複数存在する場合は1つ目（小さい方）を選択
  train.threshold.youden <- coords(mroc.train, "best", 
                                   ret="threshold", 
                                   best.method="youden")[1]
  train.threshold.topleft <- coords(mroc.train, "best", 
                                    ret="threshold", 
                                    best.method="closest.topleft")[1]
  
  mroc.test <- roc(test_y, pred.prob.test[,1])
  
  # 検証群の判別性能
  scores <- coords(mroc.test, c(0.5, train.threshold.youden, train.threshold.topleft), 
                   ret=c("threshold", "sensitivity", "specificity"))
  scores <- as.vector(scores)
  names(scores) <- paste(rep(1:3, each=3), c("cutoff", "sens", "spec"), sep="_")
  scores <- c(AUC = mroc.test$auc, scores, n.feature = sum(coef.data != 0) - 1)

  # # デバッグ用
  # # ループ内の特定の箇所で止めたい場合に使用。..1がRound、..2がfoldに対応する。
  # if (..1 == 2 & ..2 == 4){
  #   browser()
  # }
  
  # CVの結果やROC curveをプロットする場合
  if (draw.plot){
    plot(lasso.cv)
    abline(v = log(lambda), lty = 3, col = "red")
    plot(lasso, xvar = "lambda", label = T)
    abline(v = log(lambda), lty = 3)
    
    plot(mroc.train, print.auc = T, main="ROC curve (train)")
    plot(mroc.test, print.auc = T, main="ROC curve (test)")
    
    # ドット引数でrepaeted CVの何回目かと、k-fold CVのどの回かを渡しておき、タイトルに用いる
    title <- paste("Round", ..1, ", fold", ..2)
    mtext(side = 3, line=0, outer=T, text = title, cex=1)
    
    ######
    # beeswarm plotを作成する
    png(paste("beeswarm/Round", ..1, "fold", ..2, "beeswarm.png", sep = "_"),
        width = 960, height = 480, pointsize = 14)
    par(mfrow = c(1, 2))
    
    # 学習群
    beeswarm(pred.prob.train ~ train_y, method = "center", pch = 20, 
             ylim = c(0, 1), xlab = "class", ylab = "probability", 
             main = paste("train_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0.5, col = 1, lwd = 2, lty = 2)
    abline(h = train.threshold.youden, col = 2, lwd = 2, lty = 2)
    abline(h = train.threshold.topleft, col = 3, lwd = 2, lty = 2)
    legend("bottomright", c(0.5, "Youden", "topleft"), col = 1:3, lwd = 2, lty = 2)
    
    # 検証群
    beeswarm(pred.prob.test ~ test_y, method = "center", pch = 20, 
             ylim = c(0, 1), xlab = "class", ylab = "probability", 
             main = paste("test_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0.5, col = 1, lwd = 2, lty = 2)
    abline(h = train.threshold.youden, col = 2, lwd = 2, lty = 2)
    abline(h = train.threshold.topleft, col = 3, lwd = 2, lty = 2)
    legend("bottomright", c(0.5, "Youden", "topleft"), col = 1:3, lwd = 1.5, lty = 2)
    dev.off()
  }
  
  return(list(score=round(scores, 3), coef=coef.data))
}


# 学習群におけるp-value, fold changeでマーカー選択
# train_y: 1 for positive, 0 for negative
FS_p_fc <- function(train_X, train_y, feature.num=20, cor.threshold=0.9, draw.plot=T){
  # 相関係数が高い変数を除外
  remove.id <- caret::findCorrelation(cor(train_X), cutoff = cor.threshold)
  
  if (length(remove.id) == 0){
    cat("No highly correlated miRNAs found\n")
  } else {
    cat(colnames(train_X)[remove.id], "removed due to high correlation\n")
  }
  
  train_X <- train_X[, -remove.id]
  
  # 陽性群か陰性群か
  train.posi <- train_y == 1
  train.nega <- train_y == 0
  # 対応のないt検定(Welch)
  p.val <- sapply(train_X, function(x) t.test(x[train.posi], x[train.nega], paired=F, var.equal=F)$p.value)
  # ボンフェローニ補正
  p.val.adj <- p.adjust(p.val, method="bonferroni")
  
  # fold change
  fc.val <- sapply(train_X, function(x) mean(x[train.posi], na.rm=T) - mean(x[train.nega], na.rm=T))
  
  res <- data.frame(p.val=p.val, fc=fc.val)
  
  # fold changeの絶対値の降順に並べた後、p-valueの昇順に並べる
  sel.feature <- res %>% 
    tibble::rownames_to_column(var="ID") %>% 
    dplyr::arrange(p.val, desc(abs(fc))) %>% 
    # 上位N個を選択
    # dplyr::top_n(num.feature) %>% 
    dplyr::slice(1:feature.num) %>% 
    dplyr::pull(ID)
  
  if (draw.plot){
    # volcano plot
    fc.lim <- ceiling(max(abs(res$fc)))
    p.lim <- ceiling(max(-log10(res$p.val)))
    plot(res$fc, -log10(res$p.val), pch=20, xlab = "Fold change", ylab = "-log10(p-value)", 
         xlim = c(-fc.lim, fc.lim), ylim = c(0, p.lim))
    # 選択マーカーのみ赤色にする
    points(res[sel.feature, "fc"], -log10(res[sel.feature, "p.val"]), pch=20, col="red",
           xlab = "Fold change", ylab = "-log10(p-value)", xlim = c(-1, 1), ylim = c(0, 8))
    abline(v=0, lty=2)
    # 単なるプロットの数合わせ
    plot.new()
  }
  
  # とりあえずマーカーだけ返すように実装
  return(sel.feature)
}


# logistic regression + lassoによる特徴選択
FS_LogisticLasso <- function(train_X, train_y, lambda.method="1se", 
                             cor.check=F, cor.threshold=0.9, draw.plot=T){

  # # 相関係数が高い変数を除外  ## ToDo: 除外したmiRNAについても、係数を０などでうめておく必要がある
  # if (cor.check){
  #   remove.id <- caret::findCorrelation(cor(train_X), cutoff = cor.threshold)
  #   
  #   if (length(remove.id) == 0){
  #     cat("No highly correlated miRNAs found\n")
  #   } else {
  #     cat(colnames(train_X)[remove.id], "removed due to high correlation\n")
  #   }
  # 
  #   train_X <- train_X[, -remove.id]
  #   test_X <- test_X[, -remove.id]
  # }
  if (cor.check) cat("cor.check has not been implemented yet. Returning the result without cor.check\n")
  
  #### lambdaを求める
  # lambdaの最適値をCVで決める
  lasso.cv <- cv.glmnet(as.matrix(train_X), train_y, 
                        family = "binomial", alpha = 1, # logistic + lasso
                        # type.measureはdeviance, class, auc, mse, maeから選択
                        nfolds = 10, type.measure = "deviance")
  lasso <- glmnet(as.matrix(train_X), train_y, family = "binomial", alpha = 1)

  # 指定したlambdaでの係数
  if (lambda.method == "1se"){
    coef.data <- as.matrix(coef(lasso.cv, s="lambda.1se"))
  } else if (lambda.method == "min"){
    coef.data <- as.matrix(coef(lasso.cv, s="lambda.min"))
  } else {
    stop("lambda method should be 'min' or '1se'")
  }
  
  sel.feature <- rownames(coef.data)[coef.data != 0]
  sel.feature <- sel.feature[sel.feature != "(Intercept)"]
  
  # CVの結果やSolution pathをプロットする場合
  if (draw.plot){
    if (lambda.method == "1se"){
      plot(lasso.cv)
      abline(v = log(lasso.cv$lambda.1se), lty = 3, col = "red")
      plot(lasso, xvar = "lambda", label = T)
      abline(v = log(lasso.cv$lambda.1se), lty = 3)
    } else {
      plot(lasso.cv)
      abline(v = log(lasso.cv$lambda.min), lty = 3, col = "red")
      plot(lasso, xvar = "lambda", label = T)
      abline(v = log(lasso.cv$lambda.min), lty = 3)
    }
  }
  
  return(sel.feature)
}  


# BICを用いたモデル選択
modeling_LogisticBIC <- function(train_X, train_y, test_X, test_y, draw.plot=T, ...){
  full.model <- glm(train_y ~ ., data=train_X, family = "binomial")
  # BICを基準としたステップワイズ法
  best.BIC <- step(full.model, direction = "both", trace = 0, k = log(nrow(train_X)))
  
  # 係数のデータを取得
  coef.data <- best.BIC$coefficients
  names(coef.data)[1] <- "intercept"
  names(coef.data) <- gsub("`", "", names(coef.data))
  coef.data <- coef.data[c(2:length(coef.data), 1)]
  
  # print(summary(best.BIC))
  # 学習・検証サブセットでの予測確率
  pred.prob.train <- predict(best.BIC, train_X, type="response")
  pred.prob.test <- predict(best.BIC, test_X, type="response")
  
  # ROC curveから学習群・検証群のAUCを算出
  mroc.train <- roc(train_y, pred.prob.train)
  
  # 学習群で最適な閾値を決定
  # 最適動作点が複数存在する場合は1つ目（小さい方）を選択
  train.threshold.youden <- coords(mroc.train, "best", 
                                   ret="threshold", 
                                   best.method="youden")[1]
  train.threshold.topleft <- coords(mroc.train, "best", 
                                    ret="threshold", 
                                    best.method="closest.topleft")[1]
  
  mroc.test <- roc(test_y, pred.prob.test)

  # 検証群の判別性能
  scores <- coords(mroc.test, c(0.5, train.threshold.youden, train.threshold.topleft), 
                   ret=c("threshold", "sensitivity", "specificity"))
  scores <- as.vector(scores)
  names(scores) <- paste(rep(1:3, each=3), c("cutoff", "sens", "spec"), sep="_")
  scores <- c(AUC=mroc.test$auc, scores, n.feature = length(coef.data) - 1)
  
  # used for checking the result
  # browser()
  # all.res <- predict(best.BIC, rbind(train_X, test_X), type="response")
  # all.roc <- roc(c(train_y, test_y), all.res)
  # coords(all.roc, 0.5, ret=c("sensitivity", "specificity"))
  
  # ROC curveをプロットする場合
  if (draw.plot){
    plot(mroc.train, print.auc = T, main="ROC curve (train)")
    plot(mroc.test, print.auc = T, main="ROC curve (test)")
    
    # ドット引数でrepaeted CVの何回目かと、k-fold CVのどの回かを渡しておき、タイトルに用いる
    title <- paste("Round", ..1, ", fold", ..2)
    mtext(side = 3, line=0, outer=T, text = title, cex=1)
    
    ######
    # beeswarm plotを作成する
    png(paste("beeswarm/Round", ..1, "fold", ..2, "beeswarm.png", sep = "_"),
        width = 960, height = 480, pointsize = 14)
    par(mfrow = c(1, 2))
    
    # 学習群
    beeswarm(pred.prob.train ~ train_y, method = "center", pch = 20, 
             ylim = c(0, 1), xlab = "class", ylab = "probability", 
             main = paste("train_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0.5, col = 1, lwd = 2, lty = 2)
    abline(h = train.threshold.youden, col = 2, lwd = 2, lty = 2)
    abline(h = train.threshold.topleft, col = 3, lwd = 2, lty = 2)
    legend("bottomright", c(0.5, "Youden", "topleft"), col = 1:3, lwd = 2, lty = 2)
    
    # 検証群
    beeswarm(pred.prob.test ~ test_y, method = "center", pch = 20, 
             ylim = c(0, 1), xlab = "class", ylab = "probability", 
             main = paste("test_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0.5, col = 1, lwd = 2, lty = 2)
    abline(h = train.threshold.youden, col = 2, lwd = 2, lty = 2)
    abline(h = train.threshold.topleft, col = 3, lwd = 2, lty = 2)
    legend("bottomright", c(0.5, "Youden", "topleft"), col = 1:3, lwd = 1.5, lty = 2)
    dev.off()
  }
  
  return(list(score=round(scores, 3), coef=coef.data))
}


# LDAによる判別式作成
# 並列化なしのバージョンとして残してはおくが、基本的にはmodeling_LDA_parallelを使用する
modeling_LDA <- function(train_X, train_y, test_X, test_y, combn_num=5, draw.plot=T, ...){
  # combn_num: 何個のマーカーを組みあわせるか
  
  # # 全結果を保存する変数を作成
  # lda_res_all <- NULL
  # lda_cof_all <- NULL
  # 
  # combn_numよりマーカー数が少ない場合に対処
  if (ncol(train_X) < combn_num) {
    combn_num <- ncol(train_X)
    cat("Too few markers were selected; use all", ncol(train_X), "markers\n")
  }
  
  # # 組み合わせるマーカー数でループ
  # for (j in 1:combn_num) {
  # マーカーの組み合わせを生成
  j <- combn_num # 組み合わせるmarker数はcombn_numで固定
  combn_data <- combn(ncol(train_X), j)
  
  cat(ncol(combn_data), "combinations generated\n")
  
  # 結果を格納する行列
  lda_res <- matrix(nrow = ncol(combn_data), ncol= 6)
  lda_cof <- matrix(nrow = ncol(combn_data), ncol= combn_num + 1)
  
  # 全組み合わせのマーカー名
  marker_names <- apply(combn_data, 2, function(x) paste(colnames(train_X)[x], collapse="_"))
  
  for (k in 1:ncol(combn_data)) { #kはcombn_dataの列名を示し、選択したmiRNAセットを取り出す
    marker_id <- combn_data[,k]
    # 組み合わせるmiRNAのみのデータ
    train_X_marker <- train_X[, marker_id, drop=F]
    test_X_marker <- test_X[, marker_id, drop=F]
    
    # 学習群のデータで判別式作成
    hyp.plane <- lda(train_y ~ ., data=train_X_marker, prior=c(0.5, 0.5))
    
    # 係数と定数項(全検体を用いて判別式を作成した場合の)
    coef <- as.numeric(hyp.plane$scaling)
    const <- -as.numeric(apply(hyp.plane$means %*% hyp.plane$scaling, 2, mean))
    
    # 検証群の予測結果
    pred_res <- predict(hyp.plane, test_X_marker)
    
    # 判別インデックスを計算する
    train_index <- as.numeric(as.matrix(train_X_marker) %*% coef + const)
    test_index <- as.numeric(as.matrix(test_X_marker) %*% coef + const)

    # AUCの算出
    mroc.train <- roc(train_y, train_index)
    mroc.test <- roc(test_y, test_index)
    
    # 検証群の判別性能
    train.scores <- coords(mroc.train, 0, ret=c("sensitivity", "specificity"))
    train.scores <- c(auc=mroc.train$auc, train.scores)
    test.scores <- coords(mroc.test, 0, ret=c("sensitivity", "specificity"))
    test.scores <- c(auc=mroc.test$auc, test.scores)
    
    # 結果を格納
    lda_res[k, ] <- c(train.scores, test.scores)
    lda_cof[k, 1:j] <- coef
    lda_cof[k, ncol(lda_cof)] <- const
  }
    
  # 列名、行名をつける
  lda_res <- data.frame(lda_res)
  lda_cof <- data.frame(lda_cof)
  rownames(lda_res) <- rownames(lda_cof) <- marker_names
  colnames(lda_res) <- c("train.AUC", "train.sens", "train.spec",
                         "test.AUC", "test.sens", "test.spec")
  colnames(lda_cof) <- c(paste0("coef", 1:combn_num), "const")
  
  
  # # 全体の結果に結合
  # lda_res_all <- rbind(lda_res_all, lda_res)
  # lda_cof_all <- rbind(lda_cof_all, lda_cof)
# }
  
  # 学習群でのAUCが高い順にソート
  lda_res <- lda_res[order(lda_res$train.AUC, decreasing = T), ]
  lda_cof <- lda_cof[rownames(lda_res),]
  
  # AUCが最高の式の係数
  miRNA_name <- strsplit(rownames(lda_res)[1], "_")[[1]]
  coef_data <- lda_cof[1,]
  colnames(coef_data) <- c(miRNA_name, "intercept")
  
  if (draw.plot){
    # ROC curveを書くためにindexを計算する
    train.index <- as.numeric(as.matrix(coef_data[-length(coef_data)]) %*% t(train_X[miRNA_name]) + 
                                as.numeric(coef_data[length(coef_data)]))
    test.index <- as.numeric(as.matrix(coef_data[-length(coef_data)]) %*% t(test_X[miRNA_name]) + 
                               as.numeric(coef_data[length(coef_data)]))
    roc.train <- roc(train_y, train.index)
    roc.test <- roc(test_y, test.index)
    
    plot(roc.train, print.auc = T, main="ROC curve (train)")
    plot(roc.test, print.auc = T, main="ROC curve (test)")
    # ドット引数でrepaeted CVの何回目かと、k-fold CVのどの回かを渡しておき、タイトルに用いる
    title <- paste("Round", ..1, ", fold", ..2)
    mtext(side = 3, line=0, outer=T, text = title, cex=1)
    
    ######
    # beeswarm plotを作成する
    png(paste("beeswarm/Round", ..1, "fold", ..2, "beeswarm.png", sep = "_"),
        width = 960, height = 480, pointsize = 14)
    par(mfrow = c(1, 2))
    
    # 学習群
    beeswarm(train.index ~ train_y, method = "center", pch = 20, 
             ylim = c(-5, 5), xlab = "class", ylab = "index", 
             main = paste("train_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0, col = 2, lwd = 2, lty = 2)
    
    # 検証群
    beeswarm(test.index ~ test_y, method = "center", pch = 20, 
             ylim = c(-5, 5), xlab = "class", ylab = "index", 
             main = paste("test_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0, col = 2, lwd = 2, lty = 2)

    dev.off()
  }
  
  # 検証群での判別性能をスコアとして返す
  return(list(score=round(lda_res[1,4:6], 3), coef=coef_data))
}



# LDAによる判別式作成(foreachとdoParallelによる並列処理版)
modeling_LDA_parallel <- function(train_X, train_y, test_X, test_y, combn_num=5, draw.plot=T, ...){
  # combn_num: 何個のマーカーを組みあわせるか
  # combn_numよりマーカー数が少ない場合に対処
  if (ncol(train_X) < combn_num) {
    combn_num <- ncol(train_X)
    cat("Too few markers were selected; use all", ncol(train_X), "markers\n")
  }
  j <- combn_num
  combn_data <- combn(ncol(train_X), j)
  
  cat(ncol(combn_data), "combinations generated\n")
  
  # 全組み合わせのマーカー名
  marker_names <- apply(combn_data, 2, function(x) paste(colnames(train_X)[x], collapse="_"))
  
  # foreach内で用いる関数(foreachで使うには関数内で定義する必要がある)
  do_LDA <- function(train_X, train_y, test_X, test_y, marker_id){
    # marker_id <- combn_data[,k]
    # 組み合わせるmiRNAのみのデータ
    train_X_marker <- train_X[, marker_id, drop=F]
    test_X_marker <- test_X[, marker_id, drop=F]
    
    # 学習群のデータで判別式作成
    hyp.plane <- lda(train_y ~ ., data=train_X_marker, prior=c(0.5, 0.5))
    
    # 係数と定数項(全検体を用いて判別式を作成した場合の)
    coef <- as.numeric(hyp.plane$scaling)
    const <- -as.numeric(apply(hyp.plane$means %*% hyp.plane$scaling, 2, mean))
    
    # 検証群の予測結果
    pred_res <- predict(hyp.plane, test_X_marker)
    
    # 判別インデックスを計算する
    train_index <- as.numeric(as.matrix(train_X_marker) %*% coef + const)
    test_index <- as.numeric(as.matrix(test_X_marker) %*% coef + const)
    
    # AUCの算出
    mroc.train <- roc(train_y, train_index)
    mroc.test <- roc(test_y, test_index)
    
    # 検証群の判別性能
    train.scores <- coords(mroc.train, 0, ret=c("sensitivity", "specificity"))
    train.scores <- c(auc=mroc.train$auc, train.scores)
    test.scores <- coords(mroc.test, 0, ret=c("sensitivity", "specificity"))
    test.scores <- c(auc=mroc.test$auc, test.scores)
    
    return(c(train.scores, test.scores, coef, const))
  }
  
  # 並列処理
  res <- foreach(k = 1:ncol(combn_data), .combine = rbind, .packages = c("MASS", "pROC")) %dopar% { 
    do_LDA(train_X, train_y, test_X, test_y, combn_data[,k])
  }
  
  # 組み合わせが1つしかない場合に対応 
  if (!is.matrix(res)){
    res <- t(as.matrix(res))
  }
  
  # 列名、行名をつける
  rownames(res) <- marker_names
  lda_res <- data.frame(res)[,1:6]
  lda_cof <- data.frame(res)[,-c(1:6)]
  colnames(lda_res) <- c("train.AUC", "train.sens", "train.spec",
                         "test.AUC", "test.sens", "test.spec")
  colnames(lda_cof) <- c(paste0("coef", 1:combn_num), "const")
  
  # 学習群でのAUCが高い順にソート
  lda_res <- lda_res[order(lda_res$train.AUC, decreasing = T), ]
  lda_cof <- lda_cof[rownames(lda_res),]
  
  # AUCが最高の式の係数
  miRNA_name <- strsplit(rownames(lda_res)[1], "_")[[1]]
  coef_data <- lda_cof[1,]
  colnames(coef_data) <- c(miRNA_name, "intercept")
 
  if (draw.plot){
    # ROC curveを書くためにindexを計算する
    train.index <- as.numeric(as.matrix(coef_data[-length(coef_data)]) %*% t(train_X[miRNA_name]) + 
                                as.numeric(coef_data[length(coef_data)]))
    test.index <- as.numeric(as.matrix(coef_data[-length(coef_data)]) %*% t(test_X[miRNA_name]) + 
                               as.numeric(coef_data[length(coef_data)]))
    roc.train <- roc(train_y, train.index)
    roc.test <- roc(test_y, test.index)
    
    plot(roc.train, print.auc = T, main="ROC curve (train)")
    plot(roc.test, print.auc = T, main="ROC curve (test)")
    # ドット引数でrepaeted CVの何回目かと、k-fold CVのどの回かを渡しておき、タイトルに用いる
    title <- paste("Round", ..1, ", fold", ..2)
    mtext(side = 3, line=0, outer=T, text = title, cex=1)
    
    ######
    # beeswarm plotを作成する
    png(paste("beeswarm/Round", ..1, "fold", ..2, "beeswarm.png", sep = "_"),
        width = 960, height = 480, pointsize = 14)
    par(mfrow = c(1, 2))
    
    # 学習群
    beeswarm(train.index ~ train_y, method = "center", pch = 20, 
             ylim = c(-5, 5), xlab = "class", ylab = "index", 
             main = paste("train_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0, col = 2, lwd = 2, lty = 2)
    
    # 検証群
    beeswarm(test.index ~ test_y, method = "center", pch = 20, 
             ylim = c(-5, 5), xlab = "class", ylab = "index", 
             main = paste("test_Round", ..1, ", fold", ..2))
    # カットオフ値。不要な場合はコメントアウトする。
    abline(h = 0, col = 2, lwd = 2, lty = 2)
    
    dev.off()
  }
  
  # 検証群でのスコアを返す
  return(list(score=round(lda_res[1,4:6], 3), coef=coef_data))
}