# 検証用のデータで判別性能を算出する
# create_model.Rで生成された係数のデータを与える
# 列方向にmiRNA名と定数項(intercept)、行方向に評価対象の式
# 判別様式とカットオフを記載する
# test.dataを与える
####
# より複雑な判別様式を用いる場合は学習時のモデルをRのデータとして保存して置く必要があるが、
# ロジスティック回帰やLDAだけなら、係数のデータから計算することも容易
#####
library(dplyr); library(tidyr)
# パラメータを指定したファイルを読み込む
args <- commandArgs()
cfg <- read.csv(args[6], header=F, stringsAsFactors=F)
# setwd("D:/users/YB249/Documents/判別式構築スクリプト/性能評価")
# cfg <- read.csv("config_eval.csv", header=F, stringsAsFactors=F)

# テストデータ
test.data.file <- cfg[cfg[,1] == "test_data", 2]
# 対応表
ref.table.file <- cfg[cfg[,1] == "ref_table", 2]
# 係数データ
coef.data.file <- cfg[cfg[,1] == "coef_data", 2]

# どの群について、サブグループでのスコアを算出するか
# sub.score <- c("none", "posi", "nega", "both")[4]
sub.score <- cfg[cfg[,1] == "sub_score", 2]


# 検証群の正規可済みチップデータ
test.data <- read.csv(test.data.file)
# ID列に検体名、class列に疾患名、Y列に陽性か陰性か(1 or 0)
ref.table <- read.csv(ref.table.file, stringsAsFactors = F)
# 1列目に判別手法(method)、2列目にカットオフ値(cutoff)、それ以降の列にmiRNAと定数項(intercept)
coef.data <- read.csv(coef.data.file)

# hsa-がついている場合は取り除く
colnames(test.data) <- gsub("hsa.", "", colnames(test.data))

# 定数項のっ計算用に1を入れておく
test.data["intercept"] <- 1

# ID列は両データフレームに存在するものだけになる
test.data <- merge(ref.table, test.data, by = "ID")

# 疾患群ごとの判別性能を算出する際は、class列を参照する

# miRNAとintercept列のみにした上で、行列の積を計算
# ldaの場合は定数項を足し合わせるため、従来のスクリプトとは符号を逆にしていることに注意
# all(colnames(coef.data[,-c(1:2)]) == colnames(test.data[colnames(coef.data)[-c(1:2)]]))
index <- as.matrix(coef.data[,-c(1:3)]) %*% t(test.data[colnames(coef.data)[-c(1:3)]])
colnames(index) <- test.data$ID

index.df <- cbind(coef.data[,c(1:3)], index)


# ロジスティック関数
logistic <- function(x) 1 / (1 + exp(-x))

# index.dfと正解ラベルを与えると判別性能を算出する
calc_scores <- function(index.df, true.class){
  library(pROC)
  scores.all <- NULL
  for (i in 1:nrow(index.df)){
    if (index.df[i, 2] == "logistic"){
      # logisticの場合は変換を行う
      mroc <- roc(true.class, as.numeric(logistic(index.df[i,-c(1:3)])))
    } else {
      mroc <- roc(true.class, as.numeric(index.df[i,-c(1:3)]))
    }
    # cutoffを値を与え性能を算出
    scores <- coords(mroc, index.df[i, 3], ret=c("sensitivity", "specificity"))
    scores.all <- rbind(scores.all, c(auc=mroc$auc, scores))
  }
  res.test <- cbind(index.df[,c(1:3), ], round(scores.all, 3))
  return(res.test)
}

res.test <- calc_scores(index.df, test.data$Y)


##############################
# 陽性群、陰性群のサブグループごとの感度、特異度を算出する

if (sub.score == "nega" | sub.score == "both"){
  nega.labels <- unique(test.data[test.data$Y == 0, "class"])

  scores.all.class <- data.frame()
  # サブグループでループをまわす
  for (l in nega.labels){
    # 陰性群の該当グループか、陽性群の検体を選択（陽性群もないとROC curveが描けないため）
    test.data.sub <- test.data %>% filter(class == l | Y == 1)
    index.df.sub <- index.df %>% select(Name, method, cutoff, one_of(test.data.sub$ID))
    
    scores <- calc_scores(index.df.sub, test.data.sub$Y)
    scores["class"] <- l
    
    scores.all.class <- rbind(scores.all.class, scores)
  }
  # AUC、感度も返されるが、特異度のみ保存
  nega.res <- scores.all.class %>% select(-auc, -sensitivity) %>% spread(class, specificity)
  nega.res <- nega.res[rank(index.df$Name),]
}

if (sub.score == "posi" | sub.score == "both"){
  posi.labels <- unique(test.data[test.data$Y == 1, "class"])
  
  scores.all.class <- data.frame()
  # サブグループでループをまわす
  for (l in posi.labels){
    # 陽性群の該当グループか、陰性群の検体を選択（陰性群もないとROC curveが描けないため）
    test.data.sub <- test.data %>% filter(class == l | Y == 0)
    index.df.sub <- index.df %>% select(Name, method, cutoff, one_of(test.data.sub$ID))
    
    scores <- calc_scores(index.df.sub, test.data.sub$Y)
    scores["class"] <- l
    
    scores.all.class <- rbind(scores.all.class, scores)
  }
  # AUC、特異度も返されるが、感度のみ保存
  posi.res <- scores.all.class %>% select(-auc, -specificity) %>% spread(class, sensitivity)
  posi.res <- posi.res[rank(index.df$Name),]
}

# 指定に応じたスコアを出力する
if (sub.score == "none"){
  write.csv(res.test, "test_score.csv", row.names = F)

} else if (sub.score == "nega"){
  write.csv(merge(res.test, nega.res, sort = F), "test_score.csv", row.names = F)

} else if (sub.score == "posi"){
  write.csv(merge(res.test, posi.res, sort = F), "test_score.csv", row.names = F)

} else if (sub.score == "both"){
  sub.scores <- merge(posi.res, nega.res, sort = F)
  write.csv(merge(res.test, sub.scores, sort = F), "test_score.csv", row.names = F)
}

