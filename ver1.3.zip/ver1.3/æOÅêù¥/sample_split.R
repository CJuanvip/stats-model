# 検体をランダムに群分けする
# 陽性・陰性だけでなく、疾患や年齢、性別などの因子も考慮して、
# 学習群と検証群になるべく一定の比率になるように分割する
library(dplyr)

# 学習群の割合
train.ratio <- 0.7

# 臨床情報の読み込み（デモ用のデータ）
# Y: 目的変数, class: 疾患名, sex: 性別, site: 由来施設, age: 年齢
setwd("D:/users/YB249/Documents/判別式構築スクリプト/前処理")
df <- read.csv("臨床情報デモデータ.csv", stringsAsFactors=F)

dir.create("解析結果"); setwd("解析結果")

########################
# 年齢をカテゴリ化する例
df <- df %>% 
  mutate(age.bin = cut(age, breaks = c(0, 40, 50, 60, 70, 80, 100)))

########################

train.df <- df %>% 
  # 割付因子でグループ化
  # 因子が多すぎると各カテゴリの検体数が少なくなりすぎる
  ### 列名や割付因子が異なる場合は、group_byのかっこの中を修正する 
  group_by(Y, class, sex, site) %>% 
  # グループごとに一定の割合で抽出する
  sample_frac(train.ratio)

# 学習群・検証群を表す列を追加
df <- df %>% 
  mutate(cohort = ifelse(ID %in% train.df$ID, "train", "test"))

# 学習群の検体数と、全検体における割合をグループごとに計算
sample.count <- df %>% 
  ### 列名や割付因子が異なる場合は、group_byのかっこの中を修正する 
  group_by(Y, class, sex, site) %>% 
  # cohort = train, testごとに数える
  count(cohort) %>% 
  # train / (train + test)
  mutate(ratio = round(n / sum(n), 3)) 

# 結果を出力
write(train.df$ID, "train_ID.txt")
write.csv(sample.count, "res_split.csv", row.names = F)
