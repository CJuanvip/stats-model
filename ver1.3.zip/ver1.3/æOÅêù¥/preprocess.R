# 24plexのIntegrated result fileからmiRNAシグナル値を抽出し、ノーマライズする

# ディレクトリの指定
# 予めこのディレクトリに"lda_cof_data.csv"と"chip_sample_data.csv"を入れておく
# また、"Result"フォルダを作成し、チップデータを入れておく
dir_name <- "D:/users/YB249/Documents/判別式構築スクリプト/前処理/デモデータ_アルゴリズム構築"

# 検体名とチップ名の対応表のファイル名
ref_tbl_name <- "plexと検体の対応表_アルゴリズム構築.csv"

# plex単位で分割したfileを作成するか否か。最初に実行するときのみTRUEにする。
split <- FALSE

####
# ノーマライズ前のシグナル値が陽性群・陰性群の少なくとも一方の群の
# 半数以上の検体で定量下限を上回るmiRNAのみを選択する際に使用する
sig.min <- 4.3

# 陽性群と陰性群を指定
posi <- c("PC", "BC") # 膵臓がん・胆道がん
nega <- c("VOL", "BD")　# 健常・膵胆良性疾患


###############################################################################
# 検体名とチップ名の対応表を読み込む。
# ID列に検体名、class列に疾患名、out_file列にplexごとに分割後のチップデータファイル名を入れておく
setwd(dir_name)
chip_sample_data <- read.csv(ref_tbl_name, stringsAsFactors = F)

#chip_sample_dataの確認
if(!identical(chip_sample_data$file, sort(chip_sample_data$file))) cat("対応表のチップファイル名がソートされていません。\n")
if(!identical(chip_sample_data$plex, rep(1:24,nrow(chip_sample_data)/24))) cat("対応表のplexがソートされていないか欠落があります。\n")

#################################################################################

# ～Result.txtファイルを読み込む
dat_file_all <- list.files(pattern="_1Color_Gain1_Result.txt")

HEADER <- 35

#チップデータのName,S_635_Median,Flags_635,IDの列とヘッダーをリストとして格納する
list_file_data <- list_header <- as.list(NULL)

for (i in 1:length(dat_file_all)) {
  dat_file <- dat_file_all[i]
  list_file_data[[i]] <- read.delim(dat_file, skip=HEADER, header=T)[c(2:5,10,33,6)]
  list_header[[i]] <- scan(dat_file, what="", nlines=HEADER, sep="\n", quiet=T)
}

#plex単位で分割してplex番号を先頭に付加した～Result.txtファイルを作る
#検体をアプライしていないplexはファイルを出力しない
setwd(dir_name)
if (split) dir.create("split_file")
setwd("split_file")

start_row <- seq(1,7200,by=300)
end_row <- seq(300,7200,by=300)

plex_num <- paste0("p",c(paste0(0,1:9),10:24))

#chip_sample_dataがチップ名→plex番号でソートされていないと分割に失敗するので注意
#一回だけ実行すればよい
if (split) {
  for (i in 1:length(dat_file_all)) {
    for(p in 1:24) {
      if(!is.na(chip_sample_data$ID[p+(i-1)*24])) {
        suppressWarnings(write(list_header[[i]], paste0(plex_num[p],"_",dat_file_all[i]), sep="\n"))
        suppressWarnings(write.table(list_file_data[[i]][start_row[p]:end_row[p],], paste0(plex_num[p],"_",dat_file_all[i]), 
                                     append=T, quote=F, sep="\t", row.names=F))
      }
    }
  }
}


# NAを除外
chip_sample_data <- chip_sample_data[!is.na(chip_sample_data$ID),]

# 解析対象のclassのみにする
chip_sample_data <- chip_sample_data[chip_sample_data$class %in% c(posi, nega),]

# 検体名が数字の場合に頭から0を埋めて桁数をそろえる
# chip_sample_data$ID <- formatC(as.numeric(chip_sample_data$ID), width=3,flag="0")

# 検体名が昇順に並ぶようにする。
chip_sample_data <- chip_sample_data[order(chip_sample_data$ID),]



#検体名順に出力したチップファイル名を格納する
dat_file_all <- chip_sample_data$out_file

#oligo_dataはこれで完了
oligo_data <- read.delim(dat_file_all[1], skip=HEADER, header=T, stringsAsFactors=F)[c(4,7)]

#Nameのカラムで初期化する
raw_data <- flag_data <- oligo_data[1]
#S_635_MedianとFlags_635のカラムを抜き出してファイルごとに連結する
for (i in 1:length(dat_file_all)) {
  dat_file <- dat_file_all[i]
  tmp <- read.delim(dat_file, skip=HEADER, header=T, stringsAsFactors=F)[c(5,6)]
  raw_data <- cbind(raw_data, tmp[1])
  flag_data <- cbind(flag_data, tmp[2])
}
colnames(flag_data)[-1] <- colnames(raw_data)[-1] <- chip_sample_data$ID

#flag_dataのOKを0,NGをNAに置換する
flag_data[,-1] <- ifelse(flag_data[,-1] == "OK", 0, NA)

#フラグの箇所をNAにする。
raw_data[,-1]  <- raw_data[,-1] + flag_data[,-1] 

#####################################

#解析結果を保存するフォルダを作成して移動する
setwd(dir_name)
suppressWarnings(dir.create("../解析結果"))
setwd("../解析結果")

library(dplyr)
# BLANK, S-probe, miRNAのデータを取得
blank_data <- raw_data %>% filter(Name == "BLANK")
#S-probeはIDのカラムに記載されているので、oligo_dataの行数を利用してraw_dataから抜き出す
S_probe_data <- raw_data %>% 
  filter(grepl("S-Probe", oligo_data[,2])) %>% 
  arrange(Name)
# BLANKとS-Probe以外
dye_data <- raw_data %>% 
  filter(!(Name %in% c(blank_data$Name, S_probe_data$Name))) %>% 
  arrange(Name)

#flag_dataもmiRNAデータのみにする
flag_data <- flag_data %>% filter(Name %in% dye_data$Name)


#BLANKについて計算する
num <- nrow(blank_data)
num_005 <- round(num * 0.05 ,0) #sortしたBLANKの上下5%をカットするため
low <- num_005 + 1
up <- num - num_005

#NAは最もノイズが大きいものとして扱う
sort_blank <- apply(blank_data[-1], 2, sort, na.last=T)
#各チップのblankデータのソート。文字が含まれていると値がベクトルにならないので注意
sort_blank_data <- cbind(blank_data[1], sort_blank)
rownames(sort_blank_data) <- NULL #sortしているので行番号は無意味


blank_stat <- function(x) {
  blank_MEDIAN <- median(x[low:up], na.rm=T)
  blank_MEAN <- mean(x[low:up], na.rm=T)
  blank_SD <- sd(x[low:up], na.rm=T)#下限と上限の5%をCUT
  blank_MEAN_2SD <- blank_MEAN + 2 * blank_SD
  blank_CV <- blank_SD/blank_MEAN * 100
  
  return(c(blank_MEDIAN, blank_MEAN, blank_SD, blank_MEAN_2SD, blank_CV))
}#戻り値が複数ある場合はlistにしないといけない


#列方向に求めた各list形式の戻り値をsapplyで結合する
#BLANKの統計量のデータフレーム完成
res_blank_stat <- apply(sort_blank, 2, blank_stat)
res_blank_stat <- data.frame(t(res_blank_stat))
colnames(res_blank_stat) <- c("Blank.median", "Blank.mean", "Blank.SD", 
                              "Blank.mean.2SD","Blank.CV")
res_blank_stat <- cbind(Name=NA, res_blank_stat)
res_blank_stat$Name <- rownames(res_blank_stat)

# S-Probeに関する集計


####
# BLANK mean + 2SD未満のスポットはNAにする
dye_data <- cbind(dye_data[1], mapply(function(x, y) ifelse(x < y, NA, x), 
                                      dye_data[,-1], res_blank_stat$Blank.mean.2SD))
dye_data_BG <- cbind(dye_data[1], mapply(function(x, y) x - y, 
                                         dye_data[,-1], res_blank_stat$Blank.mean))

# triplicateの中央値を求める
dye_data_BG <- dye_data_BG %>% 
  group_by(Name) %>% 
  summarise_all(median, na.rm=T)

dye_data_BG <- data.frame(dye_data_BG)
rownames(dye_data_BG) <- dye_data_BG$Name
dye_data_BG$Name <- NULL
dye_data_BG <- data.frame(t(dye_data_BG), check.names = F)

# 対数変換
log_dye_data_BG <- log2(dye_data_BG)

# FLAG dataも整形する
flag_med <- flag_data %>% group_by(Name) %>% summarise_all(median)
flag_med <- data.frame(flag_med)
rownames(flag_med) <- flag_med$Name
flag_med$Name <- NULL
flag_med <- data.frame(t(flag_med), check.names = F)


# 有効スポット数、シグナル総和値
sig_num <- apply(dye_data_BG, 1, function(x) sum(complete.cases(x)))
sig_median <- apply(dye_data_BG, 1, median, na.rm = T)
sig_sum <- rowSums(dye_data_BG, na.rm = T)

sig_data <- cbind(sig_num, sig_median, sig_sum)
colnames(sig_data) <- c("detected.miRNA", "siganl.median", "signal.sum")
rownames(sig_data) <- rownames(dye_data_BG)

# 結果出力用
stat_data <- cbind(res_blank_stat, sig_data)
raw_data_all <- rbind(blank_data, S_probe_data, dye_data)

#####################################################################
# ノーマライズ前のシグナル値が陽性群・陰性群の少なくとも一方の群の
# 半数以上の検体で定量下限を上回るmiRNAのみを選択する

# 陽性群・陰性群の検体名
posi_sample <- chip_sample_data[chip_sample_data$class %in% posi, "ID"]
nega_sample <- chip_sample_data[chip_sample_data$class %in% nega, "ID"]

# 半数以上の検体で定量下限を上回るか
posi_pass <- sapply(log_dye_data_BG[posi_sample,], function(x) sum(x > sig.min, na.rm = T) / length(x) >= 0.5)
nega_pass <- sapply(log_dye_data_BG[nega_sample,], function(x) sum(x > sig.min, na.rm = T) / length(x) >= 0.5)

# いずれかの群で条件を満たしたmiRNA
miRNA_pass <- colnames(log_dye_data_BG)[posi_pass | nega_pass]

# 除外miRNAがあった場合に出力
if (!all(posi_pass | nega_pass)){
  cat("removed as low signal:", colnames(log_dye_data_BG)[!(posi_pass | nega_pass)])
}

# 条件を満たしたmiRNAのみにする
log_dye_data_BG <- log_dye_data_BG[, miRNA_pass]
flag_med <- flag_med[, miRNA_pass]

#####################################################################

# 内因性コントロールによる補正を行う
# 基準値との差を算出
norm_cof <- 11.5 - rowMeans(log_dye_data_BG[,c("hsa-miR-149-3p", "hsa-miR-2861", "hsa-miR-4463")], na.rm=T)
# miRNAのシグナル値に加算する
norm_log_data <- log_dye_data_BG + norm_cof

###############################################
# ここまでで、BLANK mean + 2SD未満のスポット、FLAGスポットはNAになっている。これらを0で置換する.
norm_log_data[is.na(norm_log_data)] <- 0

# 補正により負の値になった場合も0で補完する
norm_log_data[norm_log_data < 0] <- 0

# FLAGスポットをNAに戻す
norm_log_data <- norm_log_data + flag_med

# FLAGスポットは他検体のシグナル値の中央値で置換する
for (i in 1:ncol(norm_log_data)){
  NA_row <- which(is.na(norm_log_data[, i]))
  if (length(NA_row) > 0){
    med_others <- median(unlist(norm_log_data[-NA_row, i]))
    norm_log_data[NA_row, i] <- med_others
  }
}
# シグナル値の前処理はここまでで完了

#############################################
# 各検体のstatを保存
stat_data <- stat_data %>% 
  mutate(FLAG.num=sapply(flag_data[,-1], function(x) sum(is.na(x))), 
         norm.coef=norm_cof)

# QC基準をチェック
stat_data <- stat_data %>%
  mutate(Blank.OK = ifelse(Blank.CV < 15, 1, 0),
         FLAG.OK = ifelse(FLAG.num <= 3, 1, 0),
         norm.OK = ifelse(norm.coef < 1.16, 1, 0),
         QC.all.OK = ifelse(Blank.OK & FLAG.OK & norm.OK, 1, 0))

# QC落ちした検体名を出力
Blank.NG <- stat_data %>% filter(Blank.OK == 0) %>% select(Name)
FLAG.NG <- stat_data %>% filter(FLAG.OK == 0) %>% select(Name)
norm.NG <- stat_data %>% filter(norm.OK == 0) %>% select(Name)

if (nrow(Blank.NG)) cat("QC落ち(BlankスポットCV値):", Blank.NG[,1])
if (nrow(FLAG.NG)) cat("QC落ち(FLAG数):", Blank.NG[,1])
if (nrow(norm.NG)) cat("QC落ち(補正係数):", norm.NG[,1])


# 生のシグナル値とバックグラウンド減算及び対数変換後のデータを出力
write.csv(raw_data_all, "raw_data.csv", row.names=F)
write.csv(log_dye_data_BG, "log_dye_BG.csv")
# QC結果及びノーマライズ後のシグナル値データを出力
write.csv(stat_data, "QC_result.csv", row.names = F)
write.csv(norm_log_data, "norm_log_data.csv")
